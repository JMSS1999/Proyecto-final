//Nombre : Jhandry Santorum Solano.
//Fecha  : 16-05-2022.
//Asignatura: Algoritmos Análisis y Programación Paralela.
//Curso     : 7mo Ciclo Computacion "A".

package com.mycompany.llamadampitrabajofinal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
public class LlamadaMPITrabajoFinal {

   //Metodos
    //Metodo para leer el Archivo.
    public String leerArchivo(Process proceso){
        String valor= "";
        String valorAux = "";
        try{
            //InputStreamReader sirve para leer caracteres, los devuelve de manera libre
            InputStreamReader pathdir= new InputStreamReader(proceso.getInputStream());
            //BufferedReader para devolver una cadena String Completa.
            BufferedReader leearchivo= new BufferedReader(pathdir);
            valor= leearchivo.readLine();//Leyendo el archivo
            //Bucle controlador
            while(valor!=null){
                valorAux= valor+'\n';
                valor= leearchivo.readLine();
            }
        }catch(IOException ex){
            Logger.getLogger(LlamadaMPITrabajoFinal.class.getName()).log(Level.SEVERE, null , ex);
        }
        return valorAux;   
    }
    
    public Process instrucciones(String comando){
        Process comandoP= null;
        try {
            //Arreglo de comandos a ejecutar.
            String arreglo[]={"bash", "-c", comando};
            comandoP=Runtime.getRuntime().exec(arreglo);
        }catch(IOException ex){
            Logger.getLogger(LlamadaMPITrabajoFinal.class.getName()).log(Level.SEVERE, null , ex);
       } 
       return comandoP;
    }
    
    
}
